# Focus UI 图集 · 2026-10-18

共 110 个截图状态，分为 6 个功能区；两份图集使用相同截图清单。所有截图来自当前工作树的生产界面与真实 Electron 渲染器；业务内容使用仓库隔离验收夹具，不代表你的实际运行记录。

## 普通图集

双击 `Focus-UI-Atlas.html`：离线单文件，支持搜索、分类、适应窗口、原始像素查看、左右切图、下载单张 PNG。`screenshots/`、`desktop-patrol/` 保留未经重新绘制的原始 PNG。`boards/` 为 6 张分区图板，`overview.jpg` 为全部界面缩略总览。

工作台截图窗口 1600×1080，渲染内容区通常 1580×998（Windows 窗口边界占用不同）；一般使用 80% 页面缩放，策略长表单使用 60% 以显示完整表单。桌面浮层保持 100% 和宿主实际尺寸。画廊和图板等比缩小，截图原始像素保留。查看很长的历史会话时保留真实滚动容器布局，不把整个历史展开成一个虚构窗口。

## Figma 图集

`Focus-Figma-Atlas.zip` 是完整的本地 Figma 插件导入包，不是已创建的在线 Figma 文件，也不是 .fig。全部图片已嵌入，无需启动服务器或配置密钥。

1. 解压导入包。
2. 在 Figma 桌面应用打开一个 Design 文件，从 Plugins → Development → Import plugin from manifest 选择 `figma-import/manifest.json`。
3. 运行 `Focus UI Atlas - Screenshot Gallery`，会新增一个图集页面，按 6 个功能区和 110 个命名 Frame 自动排版。
4. 如你的 Figma 版本要求有效插件 ID，先创建一个本地开发插件，保留它自动生成的 manifest ID，再将此包的 code.js 与其余 manifest 字段复制过去。

导入的每张截图是位图；分区、Frame 和标题可编辑，截图内的产品控件仍为图片。此包未在你的 Figma 账号内执行；当前没有可用的 Figma 连接。API 依据：https://developers.figma.com/docs/plugins/manifest/ 和 https://developers.figma.com/docs/plugins/api/properties/figma-createimage/ 。

## 覆盖范围

- Patrol：未绑定、工作区输入、记录、关系图、进度、观察、事实、工作线、文件、版本检查、冻结依据、授权与预算、待补充。
- 工作台：会话、三种全图、Context 详情/修复/编辑、草稿、主 Agent/Agents/详情、材料、文件预览、合同审批、压缩、历史阅读、无工作区、新任务、权限菜单/审批、空态和错误。
- 记忆与策略：卡片、列表、详情、整理、会话来源、策略列表/详情/编辑/导入，以及空态与读取失败。
- 设置：常规、模型目录/编辑、归档数据、英文界面。
- Agent Loop：启动、Portfolio、授权、工作线会话、压缩与恢复。
- 桌面机器人：启动窗口、机器人面板、附件、回复、产物、文件引用、停止/失败后的保存及重新启用状态。

范围按本次清单定义，新增覆盖消息选区与引用来源、附件准备/图片预览、会话模型/用量、本轮改动与 Diff/审查草稿、长期存储维护/清理预览/备份，以及服务断开恢复。

不包括 Windows 原生文件选择器、系统托盘菜单、外部 OnlyOffice 服务页面和所有无限数据组合。桌面截图记录 Chromium 生产窗口内容，不替代 Windows 桌面合成截图。启动加载是静态时刻，机器人动画为某一帧。

## 来源与验证

来源：本地 main 的固定提交快照；版本记录见 source-version.json。清单 `manifest.json` 记录每张图片的尺寸、缩放、分区和 SHA-256。截图使用既有 Context/Patrol/Loop 隔离 fixture；桌面浮层使用生产宿主及独立截图适配器，补齐 Gateway/偏好 IPC；旧处理反馈断言与当前协议不兼容，因此截图流程跳过该段，不宣称原始整套回归通过。文件引用与运行来源浏览器检查通过。图集与 Figma 插件均在本地检查，Figma 账号导入待连接或手动运行。
